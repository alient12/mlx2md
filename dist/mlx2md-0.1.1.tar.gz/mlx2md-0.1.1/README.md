<h1>MATLAB `.mlx` to Markdown `.md` Converter</h1>

<h2>Installation</h2>
```
pip install mlx2md
```

<h2>Usage</h2>
```
python -m mlx2md -i example.mlx
```